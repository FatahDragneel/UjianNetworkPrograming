<?php
/**
 * [$nomer_penduduk description]
 * VARIABEL INI BERASAL DARI INDEX.HTML
 * digunakan untuk menampung data nomer induk kependudukan
 * 18-01-2023 slamet
 * edited 20-01-2023 slamet
 * @var [type]
 */
$nomer_penduduk=$_POST["0405"];
$nama_kamu=$_POST["zulkifli"];
$alamat=$_POST["jambi"];
echo "$nomer_penduduk $nama_kamu $alamat";