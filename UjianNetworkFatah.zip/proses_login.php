<?php
$nama=$_POST["nama"];
$password=$_POST["password"];
include "koneksi.php";
$query=mysqli_query($konek, 'SELECT * FROM tb_pengguna WHERE nama_pengguna="'.$nama.'" AND sandi_pengguna="'.$password.'"');
	// ini nanti di redirect ke halaman utama
	header("location:beranda.html")
?>
