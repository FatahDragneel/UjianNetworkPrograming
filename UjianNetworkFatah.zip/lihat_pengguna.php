<!DOCTYPE html>
<html>
<head>
	<title>Halaman beranda</title>
	<style type="text/css">
		ul {  
			list-style-type: none;  
		}
		a:link { text-decoration: none; }
	</style>
</head>
<body bgcolor="silver">
	<table  width="100%" border="2">
		<tr>
			<td colspan="2" bgcolor="white">
				<center>
					<h1>Welcome My Website</h1>
				</center>
				</td>
			
		</tr>
		<br>
			<ul>
				<li>
					<a href="beranda.html">
						Beranda
					</a>
					<a href="lihat_pengguna.php"> | Lihat Pengguna</a>
				</li>
			</ul>
			</td>
			<td>
			<b><u>LIST PENGGUNA</u></b><br>
			<?php 
				include "koneksi.php";
				$kueri=mysqli_query($konek,'SELECT * FROM tb_pengguna');
				?>
				<table border="1">
					
					<tr>
						<td>
							<b>
							No
						</b>
						</td>
						<td>
							<b>
							Nama Pengguna
						</b>
						</td>
						<td>
							<b>
							Sandi Pengguna
						</b>
						</td>
						<td>
							<b>
							Aksi
							</b>
						</td>
					</tr>

				<?php
				while($row = mysqli_fetch_array($kueri)){
					echo"<tr><td>";
					echo $row['id_pengguna'];
					echo "</td><td>";
					echo $row['nama_pengguna'];
					echo"</td><td>";
					echo $row['sandi_pengguna'];
					echo"</td>
					<td>";
					echo"
						<a href='hapus.php?apanih=".$row['nama_pengguna']."'>Hapus</a>
					";
					
					echo" 
                           <a href='update_data.php?apanih=".$row['nama_pengguna']." &sandi=".$row['sandi_pengguna']."        '>Ubah</a>";

				}
			?>
			</table>
			<br>
			<button><a  href="tambah_pengguna.php">Tambah Pengguna</a></button>
			</td>
		</tr>
	</table>
</body>
</html>