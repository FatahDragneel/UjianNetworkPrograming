<?php
$nama=$_POST["nama_pengguna"];
$password=$_POST["sandi_pengguna"];
include "koneksi.php";
$kueri=mysqli_query($konek,"INSERT INTO tb_pengguna (nama_pengguna, sandi_pengguna) VALUES ('$nama','$password')");
if($kueri){
	// ini nanti di redirect ke halaman utama
	header("location:lihat_pengguna.php");
}else{
		// ini nanti di redirect ke halaman login
	header("location:tambah_pengguna.php");	
}