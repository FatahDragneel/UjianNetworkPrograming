<?php
	$nama=$_GET['apanih'];
	$sandi=$_GET['sandi'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Biodata</title>
</head>
<body>
	<b>Ubah Biodata Mahasiswa</b>
	<form action="aksi_update.php" method="POST">
	<table border="1">
		<tr>
			<td>
				NAMA
			</td>
			<td>
				<INPUT NAME="nama" TYPE="TEXT" PLACEHOLDER="nama anda" value="<?=$nama;?>" readonly>
			</td>
		</tr>
		<tr>
			<td>
				PASSWORD
			</td>
			<td>
				<INPUT NAME="password" TYPE="TEXT" PLACEHOLDER="sandi anda" value="<?=$sandi;?>">
			</td>

		</tr>
		<tr>
			
			<td>
				<INPUT  TYPE="submit" value="Rubah Data">
			</td>
		</tr>
	</table>
	</form>

</body>
</html>
<?php

?>