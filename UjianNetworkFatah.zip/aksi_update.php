<?php 
include "koneksi.php";
$nama=$_POST['nama'];
$password=$_POST['password'];
$query="UPDATE tb_pengguna SET sandi_pengguna='$password' WHERE  nama_pengguna='$nama'";
mysqli_query($konek, $query);
header("location:lihat_pengguna.php");






//if(empty($nama)&&empty($password)){
	//echo "<script language='javascript'>alert('Maaf Tidak Ada Perubahan Data')
		//window.location.href='lihat_pengguna.php'
	//</script>";
		
//}else if(empty($nama)){
	//mysqli_query($konek,"UPDATE tb_pengguna SET sandi_pengguna='".$password."' WHERE nama_pengguna='".$nama."'");
	//header("location:lihat_pengguna.php");
//}else if(empty($password)){
	//mysqli_query($konek,"UPDATE tb_pengguna SET nama_pengguna='".$nama."' WHERE nama-pengguna='".$nama."'");
	//header("location:lihat_pengguna.php");
//}else{
//}